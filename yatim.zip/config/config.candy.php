<?php
$copyright = 'Margana CBT';

define("VERSI", "2.8.0");
define("REVISI", "3");
define("APLIKASI", "MARGANA CBT");
define("NAMA_DATABASE", "margana");
define("VERSI_DB", "2.8.1");
define("BASEPATH", "marganacbt");
