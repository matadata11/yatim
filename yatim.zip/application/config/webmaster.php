<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['version']      = '1.0';
$config['Aauthor']      = 'Not Found Indonesia';
$config['sistem']       = 'SISY';
$config['email']        = 'matadata.dev2021@gmail.com';
