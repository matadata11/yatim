<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-03 03:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:38:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:39:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:01 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\backend\navbar.php 8
ERROR - 2022-12-03 09:39:01 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:39:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:01 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:02 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:14 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\backend\navbar.php 8
ERROR - 2022-12-03 09:39:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:50 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\backend\navbar.php 8
ERROR - 2022-12-03 09:39:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:50 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:39:50 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:40:35 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\backend\navbar.php 8
ERROR - 2022-12-03 09:40:35 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:40:35 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:40:36 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:41:28 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\backend\navbar.php 8
ERROR - 2022-12-03 09:41:28 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:41:28 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\master\master_pengaturan.php 90
ERROR - 2022-12-03 09:41:28 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\master\master_pengaturan.php 96
ERROR - 2022-12-03 03:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:41:29 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:41:29 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:41:55 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:41:55 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\master\master_pengaturan.php 90
ERROR - 2022-12-03 09:41:55 --> Severity: Notice --> Undefined index: picture C:\xampp\htdocs\yatim\application\views\master\master_pengaturan.php 96
ERROR - 2022-12-03 03:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:41:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:41:56 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:00 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:00 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:00 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:19 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:19 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:20 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:25 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:25 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:26 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:27 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:27 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:42:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:28 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:31 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:31 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:42:31 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:43:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:43:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:43:19 --> Query error: Unknown column 'admin' in 'where clause' - Invalid query: SELECT *
FROM `mt_admin`
WHERE `admin` = 'Administrator'
ORDER BY `id_admin` DESC
ERROR - 2022-12-03 03:43:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:43:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:43:53 --> Severity: Notice --> Undefined index: ubah C:\xampp\htdocs\yatim\application\views\master\master_user.php 49
ERROR - 2022-12-03 03:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:43:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:43:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:44:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:44:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:44:12 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:45:22 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:45:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:45:22 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:45:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:45:45 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:45:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:45:45 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:45:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:45:45 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:45:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:46:28 --> Query error: Unknown column 'sekolah' in 'field list' - Invalid query: INSERT INTO `mt_admin` (`provinsi_id`, `kabupaten_id`, `instansi_id`, `fullname`, `nip`, `jabatan`, `email`, `level`, `sekolah`, `admin`, `password`, `is_active`, `created_at`) VALUES ('1', '27', '3', 'dwi', '-', 'HD Cabang', 'dwi@notfound.id', 'Admin', NULL, 'Administrator', '$2y$10$/ysoFIh5bE8J35phulq48ujMw805AyH9u5mrN.aZn.IIWmLuNc4TW', 1, '2022-12-03')
ERROR - 2022-12-03 03:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:20 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:20 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:20 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:47 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:47:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:47:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:47 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 09:47:51 --> 404 Page Not Found: Dist/css
ERROR - 2022-12-03 03:47:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:52 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-03 03:47:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:47:52 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:08 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:08 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:14 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:18 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:48:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:48:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:18 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:48:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:52 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:48:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:48:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:49:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:06 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:06 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:50:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:07 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:21 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:21 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:22 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:50:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:43 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:44 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:50:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:44 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:47 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 09:50:47 --> 404 Page Not Found: Dist/css
ERROR - 2022-12-03 03:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:47 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-03 03:50:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:50:48 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:04 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:04 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:04 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:51:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:36 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:36 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:51:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:37 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:51:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:38 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:51:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:38 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:51:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:39 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:41 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:41 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:41 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:45 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:45 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:51:45 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:52:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:06 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:52:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:06 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:52:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:06 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:52:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:08 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:52:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:52:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:09 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:52:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:52:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:52:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:20 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:20 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:21 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:28 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:29 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:52:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:52:29 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:52:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:40 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:53:40 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 03:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:41 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:53:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:53:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:53:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 03:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:52 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:52 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:53:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:53:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:56 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:53:56 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 03:53:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:53:57 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:00 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:00 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 09:54:00 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 03:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:00 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:00 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:04 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:04 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 03:54:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:05 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:29 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:29 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:29 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:35 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:35 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 03:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:35 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:35 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:54:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:38 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:38 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 09:54:38 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 03:54:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:38 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:38 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:40 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:40 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 03:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:40 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:45 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:45 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 03:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:45 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:45 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:49 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:49 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 09:54:49 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 03:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:49 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:54 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 09:54:54 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 09:54:54 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 03:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:55 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:57 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:54:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:58 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:54:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:54:58 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:11 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:55:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:55:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:15 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:15 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:16 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:18 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:19 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:22 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:22 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:36 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:36 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:36 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:55:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:39 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:39 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:39 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:43 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:44 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:44 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:57 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:57 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:55:58 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:56:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:56:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:00 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:56:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:00 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:01 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 03:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:03 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 03:56:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:56:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:57:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:57:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:15 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:57:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:57:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:18 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:57:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:57:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:18 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:57:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:23 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:57:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:57:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:57:23 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:59:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:51 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 03:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 03:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 03:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 09:59:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:00:08 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:00:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:00:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:00:08 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:00:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:00:15 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:00:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:00:15 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:00:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:00:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:01:29 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:01:29 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:01:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:01:30 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:01:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:01:32 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:01:32 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 57
ERROR - 2022-12-03 10:01:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 57
ERROR - 2022-12-03 10:01:32 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 88
ERROR - 2022-12-03 10:01:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 88
ERROR - 2022-12-03 04:01:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:01:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:01:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:01:33 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:02:10 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:02:10 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 57
ERROR - 2022-12-03 10:02:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 57
ERROR - 2022-12-03 10:02:10 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 88
ERROR - 2022-12-03 10:02:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 88
ERROR - 2022-12-03 04:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:02:10 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:02:10 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:07:19 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:07:19 --> Severity: Notice --> Undefined variable: provinsi C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:07:19 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:07:19 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:07:19 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:07:20 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:07:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:07:40 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:07:40 --> Severity: Notice --> Undefined variable: provinsi C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:07:40 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:07:40 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:07:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:07:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:07:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:07:40 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:08:32 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:08:32 --> Severity: Notice --> Undefined variable: provinsi C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:08:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:08:32 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:08:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:08:32 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:08:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:08:32 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:08:32 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:09:07 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:09:07 --> Severity: Notice --> Undefined variable: provinsi C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:09:07 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:09:07 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:09:07 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:09:07 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:10:16 --> Severity: Notice --> Undefined variable: provinsi C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:10:16 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:10:16 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:16 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:17 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:43 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:10:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:43 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:10:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:10:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:56 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:10:56 --> Severity: Notice --> Undefined variable: provinsi C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 23
ERROR - 2022-12-03 10:10:56 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:10:56 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:10:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:10:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:10:56 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:12:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:12:16 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:12:16 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:12:17 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:12:17 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:12:17 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:12:17 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:12:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:12:17 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:12:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:12:17 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:12:18 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:12:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:13:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:13:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:13:03 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:13:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:13:03 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:13:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:13:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:13:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:13:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:13:04 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:13:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:05 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 10:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 10:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 10:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 04:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:06 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:06 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:10 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:14:10 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 66
ERROR - 2022-12-03 10:14:10 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 10:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 97
ERROR - 2022-12-03 04:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:10 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:10 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:14:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:14:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 10:14:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 10:14:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 04:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:14:30 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:17:32 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:17:32 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:17:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:17:32 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 10:17:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 04:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:17:32 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:17:32 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:17:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:17:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:18:42 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:18:42 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:18:42 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 10:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 04:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:18:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:18:43 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:18:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:20:07 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:20:07 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:20:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:20:07 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 10:20:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 04:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:20:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:20:08 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:21:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:21:03 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:21:03 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 10:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 04:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:21:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:21:04 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:21:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:21:17 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:21:17 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:21:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 73
ERROR - 2022-12-03 10:21:17 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 10:21:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 104
ERROR - 2022-12-03 04:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:21:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:21:19 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:23:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:23:12 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:23:12 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 96
ERROR - 2022-12-03 10:23:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 96
ERROR - 2022-12-03 10:23:12 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 127
ERROR - 2022-12-03 10:23:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 127
ERROR - 2022-12-03 04:23:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:23:12 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:23:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:23:12 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:23:36 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:23:36 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 96
ERROR - 2022-12-03 10:23:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 96
ERROR - 2022-12-03 10:23:36 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 127
ERROR - 2022-12-03 10:23:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 127
ERROR - 2022-12-03 04:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:23:36 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:23:36 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:23:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:23:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:23:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:24:39 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:24:39 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 74
ERROR - 2022-12-03 10:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 74
ERROR - 2022-12-03 10:24:39 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 105
ERROR - 2022-12-03 10:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 105
ERROR - 2022-12-03 04:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:24:39 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:24:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:24:39 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:26:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:26:26 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 74
ERROR - 2022-12-03 10:26:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 74
ERROR - 2022-12-03 10:26:26 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 105
ERROR - 2022-12-03 10:26:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 105
ERROR - 2022-12-03 04:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:26:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:26:27 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:28:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:28:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:28:30 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 107
ERROR - 2022-12-03 10:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 107
ERROR - 2022-12-03 04:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:28:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:28:30 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:28:49 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:28:49 --> Severity: Notice --> Undefined variable: pengumuman C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 107
ERROR - 2022-12-03 10:28:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\yatim\application\views\master\master_pindah.php 107
ERROR - 2022-12-03 04:28:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:28:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:28:50 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:28:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:29:07 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:29:07 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:29:07 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:29:59 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:29:59 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:29:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:29:59 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:19 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:19 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:20 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:39 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:39 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:39 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:30:53 --> 404 Page Not Found: admin/Pindah/add_ajax_siswa
ERROR - 2022-12-03 04:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:04 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:12 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:12 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:31:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:18 --> 404 Page Not Found: admin/Pindah/add_ajax_siswa
ERROR - 2022-12-03 04:31:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:20 --> 404 Page Not Found: admin/Pindah/add_ajax_siswa
ERROR - 2022-12-03 04:31:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:27 --> 404 Page Not Found: admin/Pindah/add_ajax_siswa
ERROR - 2022-12-03 04:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:31:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:32:04 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:32:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:32:05 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:32:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:33:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:33:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:33:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:33:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:33:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:33:47 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:33:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:33:47 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:36:20 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:36:20 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:36:20 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 04:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:36:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 10:36:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:36:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:36:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:36:26 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:37:10 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:37:10 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:37:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:37:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:37:56 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:37:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:37:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:37:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:37:56 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:38:19 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:38:19 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:38:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:38:19 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:39:17 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:39:17 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:39:17 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 04:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:39:20 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 04:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:39:21 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 04:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 10:39:21 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:16 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:17 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:54 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:56 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:40:56 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:43:47 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:43:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:43:47 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:43:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:43:50 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:43:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:43:51 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:44:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:03 --> 404 Page Not Found: Dashboard/index
ERROR - 2022-12-03 05:44:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:05 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:44:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:09 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:44:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:09 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:44:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:10 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:44:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:15 --> 404 Page Not Found: Dashboard/index
ERROR - 2022-12-03 05:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:44:17 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:45:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:40 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:41 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 05:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:44 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:44 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:45:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:45 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:48 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:48 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:49 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:45:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:52 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:45:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:45:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:45:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:56 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:45:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:45:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:45:57 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:46:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:46:01 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:46:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:46:01 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:46:02 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:46:28 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:46:28 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:46:28 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:13 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:13 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:14 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:16 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:17 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:47:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:28 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:47:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:28 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:47:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:29 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:32 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:47:33 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:49:23 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:49:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:49:23 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:49:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:49:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:49:27 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:52:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:04 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:52:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:04 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:23 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:23 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:24 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:25 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:25 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:52:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:30 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:57 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:57 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:52:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:52:58 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:53:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:53:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:53:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:27 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:43 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:53:43 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:54:54 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:54:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:54:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:55:23 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:55:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:55:23 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:55:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:55:46 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:55:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:55:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:55:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:55:47 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:56:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:56:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:56:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:56:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:56:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:56:14 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:04 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:04 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:04 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:09 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:57:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:09 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:57:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:09 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:57:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:49 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:57:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:50 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:57:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:50 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:57:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:55 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:57:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:55 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:57:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:57:55 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:58:18 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:58:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:58:18 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:24 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:25 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:25 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:59:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:59:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:31 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:59:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:31 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:59:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:31 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 05:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:35 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:35 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:35 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:59:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:38 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:38 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:38 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 05:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:52 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 05:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 05:59:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 11:59:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:00:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:00:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:19 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:20 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:20 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:22 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:22 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:30 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:00:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:34 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:34 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:00:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:34 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:36 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:36 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:00:37 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:02:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:02:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:02:08 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:02:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:02:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:02:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:02:08 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:02:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:02:09 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:02:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:02:09 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:02:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:02:10 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:03:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:03:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:03:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:03:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:03:51 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:04:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:04:58 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:04:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:04:58 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:04:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:04:58 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:05:28 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:05:28 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:05:28 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:05:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:05:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:05:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:05:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:05:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:05:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:05:50 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:05:50 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:05:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:06:33 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:06:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:06:33 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:06:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:00 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:00 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:01 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:07:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:07:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:07:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:07:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:07:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:31 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:07:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:31 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:07:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:33 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:07:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:07:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:34 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:43 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:07:44 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:08:08 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:08:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:08:09 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:08:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:09:35 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:09:36 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:09:36 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:09:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:17 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\yatim\system\libraries\Email.php 2070
ERROR - 2022-12-03 12:10:17 --> Severity: Warning --> fsockopen(): unable to connect to mail.notfound.id:587 (php_network_getaddresses: getaddrinfo failed: No such host is known. ) C:\xampp\htdocs\yatim\system\libraries\Email.php 2070
ERROR - 2022-12-03 06:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:17 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:17 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:18 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:46 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:46 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:49 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:49 --> 404 Page Not Found: Dist/css
ERROR - 2022-12-03 12:10:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:49 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-03 06:10:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:10:49 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:11:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:11:38 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:11:38 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:11:38 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:11:42 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:11:42 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:11:42 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 06:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:11:42 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:11:42 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:12:24 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:12:24 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 12:12:24 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:12:24 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 06:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:12:24 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:12:24 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:12:28 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:12:28 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:12:28 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:13:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:33 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:13:33 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 275
ERROR - 2022-12-03 12:13:33 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:13:33 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:13:33 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 06:13:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:13:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:33 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:46 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:13:46 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:13:46 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:13:46 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 06:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:46 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:13:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:13:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 382
ERROR - 2022-12-03 12:13:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 12:13:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 489
ERROR - 2022-12-03 06:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:51 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:13:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:04 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 06:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:05 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:06 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 06:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:10 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:15 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:15 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:14:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:14:15 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:14:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:18:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:18:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 383
ERROR - 2022-12-03 12:18:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 490
ERROR - 2022-12-03 06:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:18:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:18:31 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:19:10 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:19:10 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 276
ERROR - 2022-12-03 12:19:10 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 383
ERROR - 2022-12-03 12:19:10 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 490
ERROR - 2022-12-03 06:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:19:10 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:19:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:25:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:02 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:02 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:26:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:45 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:45 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:45 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:26:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 276
ERROR - 2022-12-03 12:26:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 383
ERROR - 2022-12-03 12:26:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 490
ERROR - 2022-12-03 06:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:26:51 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:27:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:27:08 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:27:08 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 276
ERROR - 2022-12-03 12:27:08 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 383
ERROR - 2022-12-03 12:27:08 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 490
ERROR - 2022-12-03 06:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:27:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:27:08 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:29:29 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:29:29 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:29:29 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:31:07 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:31:08 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:31:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:31:08 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:32:25 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:32:25 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:32:25 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:32:39 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:32:39 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:32:40 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:35:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:35:50 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:35:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:35:50 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:35:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:36:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:36:38 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:36:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:36:38 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:36:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:36:38 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:36:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:36:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:38:18 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:38:18 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:38:18 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:38:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:38:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:38:24 --> Severity: Notice --> Undefined property: stdClass::$admin_input C:\xampp\htdocs\yatim\application\controllers\admin\User.php 41
ERROR - 2022-12-03 12:38:24 --> Severity: Notice --> Undefined property: stdClass::$admin_input C:\xampp\htdocs\yatim\application\controllers\admin\User.php 41
ERROR - 2022-12-03 12:38:24 --> Severity: Notice --> Undefined property: stdClass::$admin_input C:\xampp\htdocs\yatim\application\controllers\admin\User.php 41
ERROR - 2022-12-03 06:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:39:49 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 06:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:39:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:39:50 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:39:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:39:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:41:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:41:14 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 383
ERROR - 2022-12-03 12:41:14 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 490
ERROR - 2022-12-03 06:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:41:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:41:14 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:41:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:41:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:41:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:41:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:41:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:41:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:42:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:42:02 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:42:03 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:42:03 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:42:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:42:03 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:42:40 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:42:40 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:42:40 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:42:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:42:40 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:43:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:43:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:43:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:43:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:31 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:43 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:43:43 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:43:43 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:43:43 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:43 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:43 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:43:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:43:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:43:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:43:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:43:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:43:59 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:43:59 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:43:59 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:43:59 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:44:00 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:44:00 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:00 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:45:00 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:45:00 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:45:00 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:00 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:45:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:01 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:45:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:21 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:45:21 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:45:21 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:45:21 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:22 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:44 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:45:44 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:45:44 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:45:44 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:44 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:45:44 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:46:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:46:26 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:46:26 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:46:26 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:46:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:46:27 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:46:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:47:32 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:47:32 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:47:32 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:47:32 --> Severity: Notice --> Undefined index: nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 782
ERROR - 2022-12-03 12:47:32 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:47:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:47:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:47:33 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:48:05 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:48:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:48:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:48:05 --> Severity: Notice --> Undefined index: nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 782
ERROR - 2022-12-03 12:48:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:48:06 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:48:06 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:48:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:48:16 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:48:16 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:48:16 --> Severity: Notice --> Undefined index: nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 782
ERROR - 2022-12-03 12:48:16 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 12:48:16 --> Severity: Notice --> Undefined index: nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 819
ERROR - 2022-12-03 06:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:48:16 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:48:16 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:49:03 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:49:03 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:49:03 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 12:49:03 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 786
ERROR - 2022-12-03 06:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:49:03 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:49:03 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:49:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:49:16 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:49:16 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:49:16 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:49:16 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:49:16 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:49:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:02 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:50:02 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:50:02 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:02 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:03 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:40 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:50:40 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:50:40 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:40 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:40 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:53 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:50:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:50:53 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:53 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:50:53 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:52:26 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:52:26 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:52:26 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:52:26 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:52:26 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:54:27 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:54:27 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:54:27 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:54:27 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:54:27 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:58:24 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:58:24 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:58:24 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:58:24 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:58:24 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:58:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:58:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:58:31 --> Severity: Notice --> Undefined property: stdClass::$Sekolah C:\xampp\htdocs\yatim\application\controllers\admin\Pindah.php 46
ERROR - 2022-12-03 12:58:31 --> Severity: Notice --> Undefined property: stdClass::$Sekolah C:\xampp\htdocs\yatim\application\controllers\admin\Pindah.php 46
ERROR - 2022-12-03 12:58:31 --> Severity: Notice --> Undefined property: stdClass::$Sekolah C:\xampp\htdocs\yatim\application\controllers\admin\Pindah.php 46
ERROR - 2022-12-03 06:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:59:11 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:59:11 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:59:11 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:59:11 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:59:11 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:59:49 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 12:59:49 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 12:59:49 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 06:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:59:49 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 06:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 12:59:49 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 06:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 06:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:00:33 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:00:33 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:00:33 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:00:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:00:33 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:00:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:00:33 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:00:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:05 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:01:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:01:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:01:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:01:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:05 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:22 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:22 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:23 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:25 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:01:25 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:01:25 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:25 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:01:25 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:01:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:02:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:02:27 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:02:27 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:02:27 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:02:27 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:02:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:02:28 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:02:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:04:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:04:55 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:04:55 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:04:55 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:04:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:04:56 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:05:13 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:05:13 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:05:13 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:05:13 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:05:14 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:05:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:06:48 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:06:48 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:06:48 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:06:48 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:06:48 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:07:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:07:46 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:07:46 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:07:46 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:07:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:07:46 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:07:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:07:46 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:09:30 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:09:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:09:30 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:09:30 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:09:30 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:09:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:36 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:36 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:36 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:36 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:36 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:10:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:50 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:50 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:50 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:51 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:51 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:51 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 13:10:52 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:10:52 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:10:52 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:52 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:10:52 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:10:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:11:55 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:11:55 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:11:55 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:11:55 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:11:55 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:12:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:12:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:12:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:12:23 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:12:23 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:12:23 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:12:24 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:12:24 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:13:54 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:13:54 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:13:54 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:13:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:13:58 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:13:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 278
ERROR - 2022-12-03 13:13:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:13:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:13:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:13:58 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:13:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:13:59 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:02 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:14:02 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 278
ERROR - 2022-12-03 13:14:02 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:02 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:02 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:14:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:02 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:02 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:05 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 278
ERROR - 2022-12-03 13:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:05 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:05 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:05 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:14:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:14 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:14:14 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:14 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:14 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:14:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:14 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:14 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 07:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:20 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:14:20 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:20 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:20 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 13:14:20 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:20 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:20 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 07:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:23 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:23 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:23 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 07:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:35 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:35 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:35 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 07:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 07:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:37 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:37 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:37 --> 404 Page Not Found: Backgrounjpg/index
ERROR - 2022-12-03 07:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:41 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:41 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:42 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:47 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:14:47 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:47 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:47 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 13:14:47 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:47 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:47 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:56 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 07:14:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:56 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:57 --> 404 Page Not Found: admin/Backgrounjpg/index
ERROR - 2022-12-03 07:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:58 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\yatim\application\views\backend\navbar.php 28
ERROR - 2022-12-03 13:14:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 385
ERROR - 2022-12-03 13:14:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 13:14:58 --> Severity: Notice --> Undefined property: stdClass::$nm_provinsi C:\xampp\htdocs\yatim\application\views\master\master_siswa.php 492
ERROR - 2022-12-03 07:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:58 --> 404 Page Not Found: Vendor/bootstrap
ERROR - 2022-12-03 07:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-12-03 13:14:58 --> 404 Page Not Found: admin/Backgrounjpg/index
