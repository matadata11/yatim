<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['version']      = 'Beta';
$config['Aauthor']      = 'Not Found Indonesia';
$config['sistem']       = 'SISY';
$config['email']        = 'matadata.dev2021@gmail.com';
